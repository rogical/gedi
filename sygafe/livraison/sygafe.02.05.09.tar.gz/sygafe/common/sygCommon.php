<?php

/****************************************************************************************/
/********************************* sygCommon.php ****************************************/
/****************************************************************************************/
/* auteur : David MORIN									*/
/* Description: d�finition de constantes et de variables communes aux fonctions de 	*/
/* l'application.		 							*/
/*  											*/
/* fonctions:										*/
/*  											*/
/****************************************************************************************/

/******************   D�claration des variables globals *************************************/ 

//chemin relatif a la racine du r�pertoire utilisateur
$repUtil = "";

//ensemble des syst�mes stock�s dans le fichier listant les projets
$systemes = array();

//ensemble des syst�mes retenus � savoir ceux v�rifiant le crit�re de recherche
//rentr� par l'utilisateur
$systemesRetenus = array();

//cahier de recette r�cup�r�
$crRecupere;

//descripteur du fichier HTML pour le sommaire
$file_s;

//descripteur du fichier HTML pour le titre du cahier de recette
$file_t;

//descripteur du fichier HTML pour le contenu du cahier de recette
$file_c;

//chapitres de ce cahier de recette
$chapitres_tab = array();

//sous-chapitres d'un chapitre donn�
$sousChap_tab = array();

//tableau des FR pour un chapitre ou un sous-chapitre
$fr_tab = array();

//tableau qui liste les langues disponibles pour un projet donn�
$lguesDispo = array();

//bool�en permettant de savoir si toutes les donn�es sont d�s�rialis�es afin de proc�der �
//la g�n�ration de la page HTML
$dataIsReady = 0;

//nombre de fiches s�lectionn�es max autori�s
$nbfiche_select_max=50;
$nbfiche_select;
$nbfiche_total;




/**************************      D�claration des fonctions communes           ******************************/
	
function verif_car_spe_gedi($passwd)
{
    $faute = False;
	$car_spe_interd = "' , ^ )";
	$tab_car_spe = explode( " ",$car_spe_interd);
	$nbcartab= count($tab_car_spe);
	$passwd_reconst=$passwd;
	for($i=0;($i<$nbcartab) & ($faute == False);$i++){
		if(strstr($passwd_reconst, $tab_car_spe[$i])){
			// imagine qu'on a plusieurs de car speciales, traitement � revoir
			$faute = True;
		}
	}
	return $faute;
}  // fin de la  function verif_car_spe_gedi
	
//Cette fonction permet de recr�er le mot de passe au norme de la commande gediget 	
function relance_gediget($passwd)
{

	$car_spe_iden = "[ ! \" # $ % & * + , - . / ; < = > ? @ ^ _ ` ) | } ~ ]";
	$tab_car_spe = explode( " ",$car_spe_iden);
	$nbcartab= count($tab_car_spe);
	$car_spe="";
	//recherche des blancs dans le password
	$passwd_reconst=$passwd;
	//recherche des blancs dans le password
	$part_passwd = explode ( " ",$passwd_reconst);
	$lgpasswd=count($part_passwd);

	if ($lgpasswd > 1) {  
	// password contient au moin 1 blanc
      $passwd_reconst=implode("+",$part_passwd);
	}
	//recherche des anti_slash dans le password
	$part_passwd = explode ( "\\",$passwd_reconst);
	$lgpasswd=count($part_passwd);
	if ($lgpasswd > 1) {  
	// password contient au moin 1 slash
		$passwd_reconst=implode("\\\\",$part_passwd);
	}
	for($i=0;$i<$nbcartab;$i++){
		if(strstr($passwd_reconst, $tab_car_spe[$i])){
			// imagine qu'on a plusieurs de car speciales, traitement � revoir
			$part_passwd = explode ( $tab_car_spe[$i],$passwd_reconst);
			$antislash="\\";
			$car_spe = "$antislash$tab_car_spe[$i]";
			$passwd_reconst=implode($car_spe,$part_passwd);
			//echo " password en traitements des car special : $passwd_reconst <br>";
				
		}
	}
	$passwd_reconst = "\"$passwd_reconst\"";
	return $passwd_reconst;
} // fin de la function relance_gediget

//cette fonction permet de savoir si un element est present dans un tableau
//$type vaut "entier" ou "chaine" 
function isPresent($tab, $elt, $type="entier"){
	for($i = 0; $i < count($tab); $i++) {
		if (strcmp($type,"entier")==0) {
			if ($tab[$i] == $elt) return 1; //true
		} elseif (strcmp($type,"chaine")==0) {
			if (strcmp($tab[$i],$elt) == 0) return 1; //true
		} else {
			die(sprintf("probleme valeur parametre type = chaine ou entier !"));
		}
	}
	return 0;
} // fin de la function isPresent


//Cette fonction supprime les r�pertoires utilisateurs � interval r�gulier d'une semaine et le lundi
//� la premi�re ex�cution de SYGAFE
//Si le fichier lastReset.syg est absent on le cr�e. Ce fichier contient la date du dernier
//effacement des r�pertoires utilisateurs. Cette date est en seconde et correspond au timestamp
//Unix. On r�initialise la valeur stock�e dans le fichier � chaque effacement des r�pertoires soit
//toutes les 604800 sec (7*24*60*60) et que le jour courant soit le lundi 
function deleteRepUtil()
{
//version 2.06
	global $racineSyg,$racineSygTemp;
	global $nameSygTemp, $file_orig, $file_3DR, $ref_CR, $ref_3DR;
	global $file_count_date; //JNG ajout le 26/10/2006
	$xml = ".xml";
	$xzip = ".xzip";
	$trouve = 0;

		//on recherche le fichier lastReset.syg, s'il n'existe pas on le cr�e.
	$files_root = list_dir($racineSygTemp.$nameSygTemp."/");
	foreach($files_root as $file) {
		if (ereg("lastReset.syg", $file)) {
				$trouve = 1;
		}
		//en mode debug recherche le fichier erori et le supprimer
		if (ereg("erori", $file)) {
				system("rm -fR $racineSyg$nameSygTemp/$file");
		}
	}
	$currentTime = mktime(date("h"), date("i"), date("s"), date("m"), date("d"), date("Y"));

	if ($trouve == 0) {
		if (!$file_reset = fopen($racineSygTemp.$nameSygTemp."/lastReset.syg","w")) {
		 	die("Impossible de cr�er le fichier de r�initialisation lastReset.syg");
		} else {
		 	$fs = serialize($currentTime);	
		 	fputs($file_reset, $fs);
		 	fclose($file_reset);
		}
	}	
	$jourdelasemaine=date("l");
	//$jourdelasemaine="Monday";

	if ($jourdelasemaine == "Monday") {
		if (!$file_reset = fopen($racineSygTemp.$nameSygTemp."/lastReset.syg","r")) {
			 die("Impossible de lire le fichier de r�initialisation lastReset.syg");
		} else { 		
			$var = fgets($file_reset, 4096);	
			$lastTime = unserialize($var);
			fclose($file_reset);
		}
		$expiration = $lastTime + (7*24*60*60);
		if ($currentTime > $expiration){
			if (!$file_reset = fopen($racineSygTemp.$nameSygTemp."/lastReset.syg","w")) {
			 	die("Impossible de cr�er le fichier de r�initialisation lastReset.syg");
			} else {
			 	$fs = serialize($currentTime);	
			 	fputs($file_reset, $fs);
			 	fclose($file_reset);
			}
		}else{  //on efface tout ce que contient sygTemp sauf le fichier lastReset.syg
			$filesRep = list_dir($racineSygTemp.$nameSygTemp);
			foreach($filesRep as $file) {
				if (!ereg("lastReset.syg", $file) and !ereg("counter", $file))
					system("rm -fR $racineSygTemp$nameSygTemp/$file");
			}
				//on remplace les fichiers listeCR et Correspondances_FR-3DR.xml avec les eventuelles nouvelles version GEDI
			system("rm  $racineSygTemp$nameSygTemp/Correspondances_FR-3DR.xml liste_cr.xml");
			
			 //	file_gedi($ref_CR, $file_orig.$xzip); 
			 //	file_gedi($ref_3DR, $file_3DR.$xzip);
				
			$files = list_dir("$racineSygTemp$nameSygTemp/");
			foreach ($files as $file){
				$chDirOk = chdir("$racineSygTemp$nameSygTemp");			 	
				if (ereg("$ref_CR",$file)){
				 	$nomreferenceCR = $file;
				 	system("cp  $nomreferenceCR $file_orig.$xml");
				 	system("rm  $nomreferenceCR ");
				}
				 if (ereg("$ref_3DR",$file)){
				 	$nomreference3DR = $file;
				 	system("cp  $nomreference3DR $file_3DR.$xml");
				 	system("rm  $nomreference3DR ");
				}
			}
		}
	}			
}  //  fin de la function deleteRepUtil


//cette fonction lit les fichiers (mais pas les r�pertoires) contenu dans un r�pertoire et renvoie son contenu dans un tableau
function list_dir($dirname)
{
	$result_array = array();
	
	//JNG trace
	//echo " sygCommon.list_dir =>ligne 305 : dir courant = $dirname<br>";
	//fin trace
	
	$handle=opendir($dirname);
	while ($file = readdir($handle))
	{
		if($file=='.'||$file=='..')
			continue;
		$result_array[]=$file;
	}	
	closedir($handle);
	return $result_array;
} // fin de la function list_dir


//cette fonction apporte un fichier xml du gedi 
function file_gedi($reference, $filename)
{
	global $identificationCIl, $racineSygTemp,$racineSyg, $nameSygTemp, $file_orig, $file_3DR, $ref_CR, $ref_3DR;
	global $motdepasse,$login_user,$passwd;
	
	$lgue = "FR";
	$nomFileXzip = "";

	$dir_courant = getcwd();
	
	$chDirOk = chdir("$racineSygTemp$nameSygTemp");

	if ( $chDirOk == false) {
		die("pb chdir script sygMainStep1!!");
	} else {
	
			//$motdepasse = relance_gediget($passwd);
			//$identificationCIl = "-cn $login_user -pass $motdepasse";
			$identificationCIl = "";
			system(escapeshellcmd("gediget ".$reference." ".$lgue." $identificationCIl -save $filename", $resCde));	
			
			//echo " sygCommon file_gedi =>ligne 311 : retour premi�re  d'appel gediget <br>";
			//echo " ref=$reference $lgue  Id=$identificationCIl -save file=$filename, code retour = $resCde<br>";

		if ($resCde != 0) {
			$motdepasse = relance_gediget($passwd);
			$identificationCIl = "-cn $login_user -pass $motdepasse";
			//$identificationCIl = "";
			system(escapeshellcmd("gediget ".$reference." ".$lgue." $identificationCIl -save $filename > $racineSygTemp$nameSygTemp/resCdes", $resCde));
			
		} // fin  if ($resCde != 0)
			//on analyse le r�sultat de la commande afin de savoir si
	//c'est un pb se serveur FTP Gedi ou que le document n'est pas dans
	//la base
		if ($resCde != 0) {
			echo("<BR><BR>\n");
			echo("<FONT COLOR=\"#000000\" SIZE=\"5\">\n");
			if ($langue_browser == "FR")
				{
				echo("<B>Erreur : $reference document inexistant ou probl�me avec le serveur FTP de GEDI</B><BR><BR>\n");
			}else{
				echo("<B>Error : $reference document not found or GEDI FTP server problem</B><BR><BR>\n");
			}
			echo("</FONT>\n"); 	
		}else{
		//on r�cup�re le nom du fichier xzip (un seul) pour le d�zipper
		//$files = list_dir("$racineSyg$nameSygTemp/");
		//NGJ 04_07_07
			$files = list_dir("$racineSygTemp$nameSygTemp/");		
		//
			foreach ($files as $file){
				if (ereg(".xzip$",$file)){
					$nomFileXzip = $file;
				}
			}
		}
	}  //fin if ( $chDirOk != 0)
		//unzip du fichier
	if($nomFileXzip != ""){
		system("unzip $racineSygTemp$nameSygTemp/$nomFileXzip  >> $racineSygTemp$nameSygTemp/resCdes");
		system("rm  $racineSygTemp$nameSygTemp/resCdes");
		system("rm -f $racineSygTemp$nameSygTemp/$nomFileXzip");
	}else{
		echo("<BR><BR>\n");
		echo("<FONT COLOR=\"#000000\" SIZE=\"5\">\n");
		if ($langue_browser == "FR")
		{
			echo("<B>Erreur : Probl�me de la cr�ation du document : $reference ==> $filename</B><BR><BR>\n");
		}else{
			echo("<B>Error : Bad creation of the document:  $reference ==> $filename</B><BR><BR>\n");
		}
		echo("</FONT>\n"); 	
	}
}	// fin de la function file_gedi

// fonction utilise dans le cas des absence des fichiers liste_cr.xml ou Correspondances_FR-3DR.xml
function ficpres($file_s)
{
	global $file_orig, $file_3DR, $racineSyg, $racineSygTemp,$nameSygTemp, $ref_CR, $ref_3DR;
	$xml = ".xml";
	$xzip = ".xzip";
	
	$chDirOk = chdir("$racineSygTemp$nameSygTemp");
	$files = list_dir("$racineSygTemp$nameSygTemp/");
	foreach ($files as $file) 
	{
		if (ereg("$file_s",$file)){
			return 1;
		}		
	}
	$nrchar = strlen ($file_s);
	$file_s = substr($file_s,0,$nrchar - 4);
	if (strcmp($file_s, $file_orig) == 0) 
		{
			file_gedi($ref_CR, $file_s.$xzip);
		}
	elseif (strcmp($file_s, $file_3DR) == 0)
		{
			file_gedi($ref_3DR, $file_s.$xzip);
		}
	$files = list_dir("$racineSygTemp$nameSygTemp/");
		$chDirOk = chdir("$racineSygTemp$nameSygTemp");
			 foreach ($files as $file) 
			 	{
				 				 	
				 	if (ereg("$ref_CR",$file)) 
				 		{
				 		$nomreferenceCR = $file;
				 		system("cp  $nomreferenceCR $file_orig$xml");
				 		system("rm  $nomreferenceCR ");
				 		}
				 	if (ereg("$ref_3DR",$file)) 
				 		{
				 		$nomreference3DR = $file;
				 		system("cp  $nomreference3DR $file_3DR$xml");
				 		system("rm  $nomreference3DR ");
				 		}
				 				
			 	}	
}

// fonction debug
function erori ($local_appel,$val)
{	
	global $cil,$csl;
	global $racineSygTemp, $nameSygTemp;
	$erori = 0;
	$linie ="   \n";
	$data=($val);
	$fic = fopen ("$racineSygTemp$nameSygTemp/$csl/erori" , "a+");
	fwrite($fic, $csl." :: ".$local_appel."\n".$data."\n");
	fclose ($fic);
}


//**********************************************
function cre_gediInit($path_Value)
{
global $cil,$passwd;

	if (!$file_ini = fopen($path_Value,"w"))
	{  //JNG ajouter pour test
	 	die("Can not create gedi.ini file.");
	}   //JNG ajouter pour test
	else 
	{				
		//Ngj 13_06_07 remettre le blanc par le +
		$part_passwd = explode ( " ",$passwd);
		$lgpasswd=count($part_passwd);
		if ($lgpasswd > 1) {  
			// password contient au moin 1 blanc
			$passwd=implode("+",$part_passwd);
		}
	 	fwrite($file_ini, "PROXY_IP=\n");
	 	fwrite($file_ini, "PROXY_PORT=\n");
	 	fwrite($file_ini, "GEDI_IP=gedi.ln.cit.alcatel.fr\n");
	 	fwrite($file_ini, "CONFIG_FILE=configparam.xml\n");
	 	fwrite($file_ini, "CN=$cil\n");
	 	fwrite($file_ini, "PASSWD=$passwd\n");
	 	fwrite($file_ini, "FTP_IP=\n");
	 	fwrite($file_ini, "FTP_USER=\n");
	 	fwrite($file_ini, "FTP_PASSWD=\n");
	 	fwrite($file_ini, "FTP_SUBDIR=\n");
		fclose ($file_ini);
		
	}

}// fin fonction


/******************************************************************************/
//fonction lecture du fichier gedi.init pour r�cup�rer le login et le password
//parametre en entrer peut avoir les valeurs : 
//$refValue=GEDI_IP =>  gedi.ln.cit.alcatel.fr l'adresse du IP de GEDI 
//$refValue=CONFIG_FILE => configparam.xml
//$refValue=CN => login de connexion du GEDI
//$refValue=PASSWD => jacob+7452
//**********************************************
function lire_gediInit($refValue)
{
	global $cil,$csl;
	global $racineSygTemp, $nameSygTemp;
	$file_gediinit="$racineSygTemp$nameSygTemp/$csl/gedi.ini";
	
	//echo " sygcommon.lire_gediinit dans directory d'utilisateur : $file_gediinit <br>";
	
	
	if (file_exists($file_gediinit)) {
    //print "Le fichier $file_gediinit existe";
	} else {
    //print "Le fichier $file_gediinit n'existe pas : cr�ation du fichier gedi.init";
		cre_gediInit($file_gediinit);
	}

	
	
	
	//****************************
	if (!$fic = fopen ("$racineSygTemp$nameSygTemp/$csl/gedi.ini" , "r")) {
			 die("Impossible de lire le fichier gedi.ini : fichier inexistant");
	} else {
	//*****************************
	
	//$fic = fopen ("$racineSygTemp$nameSygTemp/$csl/gedi.ini" , "r");
	$ref_rech=0;
	while (!feof ($fic)) 
		{
			$buffer = fgets($fic, 4096);
			$tab_car_spe = explode( "=",$buffer);
			$nbcartab= count($tab_car_spe);
			//$CipValue="PASSWD";
			$lgrefValue=strlen($refValue);
			if (strncmp($tab_car_spe[0], $refValue,$lgrefValue) == 0)
			{ 
				//$ref_rech = $tab_car_spe[1];
				$ref_rech = rtrim($tab_car_spe[1]);
				/**/
				//$lgrefValue=strlen($ref_rech);
				//$edition_etat = "sygCommon.lire_gediINit => ligne 440 : fichier : $racineSygTemp$nameSygTemp/$csl/gedi.ini";
				//$string1000 = "$refValue=$ref_rech  longue = $lgrefValue";
				//erori ($edition_etat,$string1000);
				/**/
			}
		}
	}
	fclose ($fic);
	return $ref_rech;
}// fin fonction




// fonction 
function rempl_car_spe ($val)
{	
	$tab_car_spe = explode( "�",$val);
	$nbcartab= count($tab_car_spe);
	if ($nbcartab > 1) {  
      $val=implode("&eacute;",$tab_car_spe);
	}
		$tab_car_spe = explode( "�",$val);
	$nbcartab= count($tab_car_spe);
	if ($nbcartab > 1) {  
      $val=implode("&egrave;",$tab_car_spe);
	}
		$tab_car_spe = explode( "�",$val);
	$nbcartab= count($tab_car_spe);
	if ($nbcartab > 1) {  
      $val=implode("&agrave;",$tab_car_spe);
	}
		$tab_car_spe = explode( "&",$val);
	$nbcartab= count($tab_car_spe);
	if ($nbcartab > 1) {  
      $val=implode("&amp;",$tab_car_spe);
	}
		$tab_car_spe = explode( "�",$val);
	$nbcartab= count($tab_car_spe);
	if ($nbcartab > 1) {  
      $val=implode("&ecirc;",$tab_car_spe);
	}
		$tab_car_spe = explode( "�",$val);
	$nbcartab= count($tab_car_spe);
	if ($nbcartab > 1) {  
      $val=implode("&ocirc;",$tab_car_spe);
	}
		$tab_car_spe = explode( "�",$val);
	$nbcartab= count($tab_car_spe);
	if ($nbcartab > 1) {  
      $val=implode("&icirc;",$tab_car_spe);
	}
		$tab_car_spe = explode( "�",$val);
	$nbcartab= count($tab_car_spe);
	if ($nbcartab > 1) {  
      $val=implode("&ucirc;",$tab_car_spe);
	}
		$tab_car_spe = explode( "�",$val);
	$nbcartab= count($tab_car_spe);
	if ($nbcartab > 1) {  
      $val=implode("&acirc;",$tab_car_spe);
	}
		$tab_car_spe = explode( "�",$val);
	$nbcartab= count($tab_car_spe);
	if ($nbcartab > 1) {  
      $val=implode("&sect;",$tab_car_spe);
	}
		$tab_car_spe = explode( "<",$val);
	$nbcartab= count($tab_car_spe);
	if ($nbcartab > 1) {  
      $val=implode("&lt;",$tab_car_spe);
	}
		$tab_car_spe = explode( "�",$val);
	$nbcartab= count($tab_car_spe);
	if ($nbcartab > 1) {  
      $val=implode("&ccedil;",$tab_car_spe);
	}
		$tab_car_spe = explode( "�",$val);
	$nbcartab= count($tab_car_spe);
	if ($nbcartab > 1) {  
      $val=implode("&ugrave;",$tab_car_spe);
	}
	return $val;
}  // fin de la function rempl_car_spe

//--------------------------------------------------------------------------------------------------------------------------
//
//
//--------------------------------------------------------------------------------------------------------------------------


	$csl=$HTTP_COOKIE_VARS[Csl];
	$passwd = $HTTP_COOKIE_VARS[Cip];
	$cil = $HTTP_COOKIE_VARS[Login];
	
	$repUtil = $csl;
	$login_user = "\"$cil\"";
		
	//echo " sygCommon ligne 566 : csl=$HTTP_COOKIE_VARS[Csl]; passwd = $HTTP_COOKIE_VARS[Cip];cil = $HTTP_COOKIE_VARS[Login];<br>";
	
	$motdepasse = relance_gediget($passwd);
	$login_user = "\"$cil\"";
	
	list ($nameCil, $surnameCil)= explode ( " ",$cil);
		
	//erreur LDAP
	$cile = $cil;
	$ok = "NOK";
	for ($u = 0; $u < strlen($cil); $u++)
	{
		if ($cil[$u] == " " and $ok == "NOK")
		{
			for($p = $u+1; $p < strlen($cil); $p++)
			{
				$ok == "OK";
				if ($cil[$p] == "_") $cil[$p] = " ";
					
			}	
		}
	}
		
	// initialisation fichier gedi.ini
	global $gedinipath;
	$gedinipath = "$racineSyg$nameSygTemp/$csl";
	putenv("GEDINIPATH=$gedinipath");   
	$identificationCIl = "";
	$matrixx = array();
	$mat = array();
	$mats;
//*****



?>
